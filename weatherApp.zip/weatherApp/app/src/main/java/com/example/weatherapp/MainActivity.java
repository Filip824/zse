package com.example.weatherapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.widget.TextView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import com.squareup.picasso.Picasso;
import android.widget.EditText;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class MainActivity extends AppCompatActivity {

    private TextView weatherData;
    private final String BASE_URL = "https://api.openweathermap.org/data/2.5/";
    private final String API_KEY = "793742a1aa8cea81896e8e72211e8252";
    private ImageView imageView2;
    private EditText editText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imageView2 = findViewById(R.id.imageView3);
        weatherData = findViewById(R.id.weatherData);
        editText = findViewById(R.id.editTextText);

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        WeatherService service = retrofit.create(WeatherService.class);

        editText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    String miasto = editText.getText().toString();

                    try {
                        // Validate the input
                        if (miasto.isEmpty()) {
                            throw new IllegalStateException("Nazwa nie może być pusta");
                        }
                        if (containNumber(miasto) == true){
                            throw new Exception("Nazwa nie może zawierać liczb");
                        }
                        if (!miasto.matches("^[a-zA-ZąćęłńóśźżĄĘŁŃÓŚŹŻ\\s]+$")) {
                            throw new IllegalArgumentException("Zły znak: " + miasto);
                        }


                        Call<WeatherResponse> call = service.getCurrentWeatherData(miasto, API_KEY, "metric", "pl");
                        call.enqueue(new Callback<WeatherResponse>() {
                            @Override
                            public void onResponse(Call<WeatherResponse> call, Response<WeatherResponse> response) {
                                if (response.code() == 200) {
                                    WeatherResponse weatherResponse = response.body();
                                    assert weatherResponse != null;

                                    String description = weatherResponse.getWeather().get(0).getDescription();
                                    String iconCode = weatherResponse.getWeather().get(0).getIcon();
                                    int visibility = weatherResponse.getVisibility();
                                    double windSpeed = weatherResponse.getWind().getSpeed();
                                    int clouds = weatherResponse.getClouds().getAll();
                                    String cityName = weatherResponse.getName();

                                    String rainInfo = weatherResponse.getRain() != null ? "Rain volume for the last hour: " + weatherResponse.getRain().get_1h() + " mm\n" : "";
                                    String snowInfo = weatherResponse.getSnow() != null ? "Snow volume for the last hour: " + weatherResponse.getSnow().get_1h() + " mm\n" : "";

                                    String forecast = "Miasto: " + cityName +
                                            "\nOpis pogody: " + description +
                                            "\nWidoczność: " + visibility + " metrów" +
                                            "\nPrędkość wiatru: " + windSpeed + " m/s" +
                                            "\nZachmurzenie: " + clouds + "%" +
                                            "\n" + rainInfo +
                                            snowInfo;
                                    String iconURL = "https://openweathermap.org/img/wn/" + iconCode + ".png";
                                    Picasso.get().load(iconURL).into(imageView2);
                                    weatherData.setText(forecast);
                                }
                                else {
                                    try {
                                        throw new IllegalAccessException("brak miasta");
                                    }catch(IllegalAccessException e){
                                        weatherData.setText(e.getMessage());
                                    }
                                }
                            }

                            @Override
                            public void onFailure(Call<WeatherResponse> call, Throwable t) {
                                weatherData.setText("Błąd: " + t.getMessage());
                            }
                        });
                    }
                    catch(IllegalStateException e) {
                        weatherData.setText(e.getMessage());
                    }catch(Exception e){
                        weatherData.setText(e.getMessage());
                    }

                    return true;
                }
                return false;
            }

        });

    }

    public boolean containNumber(String miasto){
        String regex = ".*\\d.*";

        Pattern pattern = Pattern.compile(regex);

        Matcher matcher = pattern.matcher(miasto);

        if (matcher.matches()) {
            return true;
        }
        else {
            return false;
        }
    }
}
