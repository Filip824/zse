<?php declare(strict_types=1);

namespace DeepCopy\f012;

enum Suit: string
{
    case Hearts = 'Hearts';
    case Diamonds = 'Diamonds';
    case Clubs = 'Clubs';
    case Spades = 'Spades';
}
