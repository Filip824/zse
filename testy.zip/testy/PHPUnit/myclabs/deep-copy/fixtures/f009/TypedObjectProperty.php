<?php

declare(strict_types=1);

namespace DeepCopy\f009;

class TypedObjectProperty
{
    public \DateTime $date;
}
