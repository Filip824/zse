<?php declare(strict_types=1);

namespace DeepCopy\f008;

class B extends A
{
}
