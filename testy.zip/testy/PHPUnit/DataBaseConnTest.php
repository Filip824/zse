<?php
require 'vendor/autoload.php';
require 'DataBaseConn.php';

use PHPUnit\Framework\TestCase;

class DataBaseConnTest extends TestCase {
    public function testConnect() {
        $databaseConn = new DataBaseConn("localhost", "root", "", "db1");
        $databaseConn->connect();

        $this->assertTrue($databaseConn->isConnected());
    }
    public function testGet() {

    }

    public function testPut() {
    }
}