<?php declare(strict_types=1);

namespace PhpParser\Comment;

class Doc extends \PhpParser\Comment
{
}
