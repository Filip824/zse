<?php declare(strict_types = 1);
namespace PharIo\Manifest;

class ManifestElementException extends \RuntimeException implements Exception {
}
