<?php
require 'vendor/autoload.php';
require 'AuthBasic.php';

class AuthBasicTest extends \PHPUnit\Framework\TestCase {
    public function testGenFingerprint() {
        $authBasic = new AuthBasic();
        $algo = "sha512";
        $result = $authBasic->genFingerprint($algo);

        $this->assertEquals('sha512', $result);
    }


}