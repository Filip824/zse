<?php

class DataBaseConn
{
    private $host;
    private $user;
    private $pass;
    private $db;
    private $conn;

    public function __construct($host, $user, $pass, $db) {
        $this->host = $host;
        $this->user = $user;
        $this->pass = $pass;
        $this->db = $db;
    }

    public function connect(){
        $this->conn = new mysqli($this->host, $this->user, $this->pass, $this->db);

        if ($this->conn->connect_error){
            die("błąd przy połączeniu z bazą".$this->conn->connect_error);
        }
    }

    public function get($tabName, $columns, $options){
        if (empty($this->options)) {
            $selectFields = "*";
        } else {
            $selectFields = implode(", ", $options);
        }
        $sql = "SELECT".$selectFields."FROM ".$tabName;
        $result = $this->conn->query($sql);

        if($result->num_rows > 0){
            while($row = $result->fetch_assoc()){
                print_r($row);
            }
        } else{
            echo "brak danych w tabeli";
        }


    }

    public function put($tabName, $columns, $values){
        if (empty($values)) {
            echo "Nie podano wartości";
            exit();
        } else {
            $insValues = implode("', '", $values); // Dodałem pojedyncze cudzysłowy wokół wartości
        }

        $sql = "INSERT INTO " . $tabName . " VALUES ('" . $insValues . "')";
        if ($this->conn->query($sql)) {
            echo "Dodano pomyślnie:";
        } else {
            echo "Błąd przy dodawaniu: " . $this->conn->error;
        }

        // Pobierz dane z tabeli
        $result = $this->conn->query("SELECT * FROM " . $tabName);

        if ($result) {
            while ($row = $result->fetch_assoc()) {
                print_r($row);
            }
        }
    }

}

$databaseConn = new DataBaseConn("localhost", "root", "", "db1");
$databaseConn->connect();
$selectOptions = ["id", "name"];
$putValues = [1, "Filip"];
$databaseConn->get("tabela1", 0, $selectOptions);
$databaseConn->put("tabela2", 0, $putValues);