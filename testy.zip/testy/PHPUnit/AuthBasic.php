<?php
class AuthBasic
{
public function genFingerprint($algo){

}

private function createCode($length = 6, $min=1, $max=999999){

}
private function createAuthToken($email, $id){

}
public function compAuthCode($emlAuth, $idzAuth, $authCode){

}
public function doAuthByEmail($person, $email){

}
public function checkIfValidRequest($person, $email){

}
private function checkIfValidRequest2($emlAuth, $idzAuth){

}
public function verifyQuickRegCode($codeNo){

}
}