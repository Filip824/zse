import org.junit.jupiter.api.*;
import java.util.regex.*;
import static org.junit.jupiter.api.Assertions.*;

class PlayerTest {


    @Test
    @DisplayName("Utworzenie gracza")
    void createPlayerTest(){

        Player p1 = new Player();
        p1.createPlayer(true, "Filip_Kasprzak-4Tp", 2005);

        Pattern p = Pattern.compile("^[a-zA-Z0-9_-]*$");
        Matcher m = p.matcher(p1.getName());
        boolean ms = m.matches();

        assertAll(
                ()-> assertTrue(2023 - p1.getBornYear() >= 18),
                ()-> assertTrue(p1.getAgree()),
                ()-> assertTrue(ms)
        );
    }
}