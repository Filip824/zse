public class Player {
    private String name;
    private Integer bornYear;
    private Boolean agree;

    public Boolean createPlayer(Boolean agree, String name, Integer bornYear){
        this.name = name;
        this.bornYear = bornYear;
        this.agree = agree;
        return false;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getBornYear() {
        return bornYear;
    }

    public void setBornYear(Integer bornYear) {
        this.bornYear = bornYear;
    }

    public Boolean getAgree() {
        return agree;
    }

    public void setAgree(Boolean agree) {
        this.agree = agree;
    }


}