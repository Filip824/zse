const fs = require('fs')
const PDFDocument = require('pdfkit')
const { title } = require('process')
const doc = new PDFDocument({size:'B5'})
const tech = [
    'HTML5, CSS3, ES6',
    'Joomla, WordPress, PrestaShop',
    'Node.js i React',
]
const a = [
    'więcej'
]

doc.info.Author = "Filip Kasprzak"
doc.pipe(fs.createWriteStream('zadanie.pdf'))
doc.registerFont('lato','./Lato-Regular.ttf')
doc.registerFont('lato-bold','./Lato-Bold.ttf')
doc.image('./zse-logo.png', 15, 15, {
    scale: 0.3, 
    align: 'left'
})
doc.fontSize(20)
doc.font('lato-bold').text('Zespół Szkół Elektrycznych', 210, 75, {lineBreak: false})
doc.fontSize(16)
doc.font('lato').text("4TP Kasprzak Filip", 265, 100)
doc.fontSize(12)
doc.font('lato-bold').text("Znane mi technologie Web: ", 180, 225).underline(180, 210, 145, 30)
doc.font('lato')
doc.list(tech, {
    bulletRadius: 1.5
})
doc.fillColor('blue')
doc.list(a, {
    bulletRadius: 1.5,
    link: 'https://google.com'
}).underline(187.5, 287, 30, 10)

doc.end()